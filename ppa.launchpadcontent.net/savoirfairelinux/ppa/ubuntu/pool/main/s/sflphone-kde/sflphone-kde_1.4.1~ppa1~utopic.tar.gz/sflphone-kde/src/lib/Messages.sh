#! /bin/sh

$XGETTEXT_QT `find . -name '*.cpp'` -o $podir/sflphone-client-kde_qt.pot
